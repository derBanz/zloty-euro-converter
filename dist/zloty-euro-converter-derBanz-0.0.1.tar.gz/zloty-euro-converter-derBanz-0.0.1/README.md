# Zloty Euro Converter

This package was created to test the pypi packaging system. It provides access to the 'converte' method, that takes a numeric input and treats it as both a zloty and a Euro value, prodiving the converted values for both.

The current conversion rate is taken from https://github.com/fawazahmed0/currency-api.